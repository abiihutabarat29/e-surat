<!-- /.content-wrapper -->
<footer class="main-footer">
    <strong>Copyright &copy;<?= date('Y') ?> <a href="https://diskominfo.batubarakab.go.id" target="blank">Dinas
            Komunikasi dan
            Informatika Kab. Batu Bara</a> All rights reserved.</strong>
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0
    </div>
</footer>
<!-- File js.php -->
</div>
<!-- ./wrapper -->
</body>

</html>