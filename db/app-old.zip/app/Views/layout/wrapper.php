<?php
echo view('layout/head');
echo view('layout/navbar');
echo view('layout/sidebar');
echo view('layout/content');
echo view('layout/footer');
echo view('layout/js');
